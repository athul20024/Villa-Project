"""
URL configuration for villa project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path,include
from villaapp import views
from django.conf import settings
from django.conf.urls.static import static
urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.index),
    path('agency/',views.agency),
    path('user/',views.user),
    
    path('agencyHome/',views.agencyHome),
    path('userlogin/',views.userlogin),
    path('userReg/',views.userReg),
    path('register/',views.register),
    path('villaReg/',views.villaReg),
    path('viewVilla/',views.viewVilla),
    path('viewVillaA/',views.viewVillaA),
    path('deleteA/<int:id>',views.deleteA),
    path('upDateA/<int:id>',views.upDateA),
    path('orderreg/<id>/<price>',views.orderreg),
    path('userHome/',views.userHome),
    path('viewOrderUser/',views.viewOrderUser),
    path('payReg/<id>/<p>',views.payReg),
    path('viewPay/',views.viewPay),
    path('viewOrderAgency/',views.viewOrderAgency),
    path('order_approval/<id>',views.order_approval),
    path('order_rejection/<id>',views.order_rejection),
]

if settings.DEBUG:
    urlpatterns+=static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)   
    urlpatterns+=static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)